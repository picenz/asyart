<?php

namespace App\Http\Controllers;

use App\Models\CartItem;
use App\Models\ProductVariant;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\ValidationException;

class CartController extends Controller
{

public function index(Request $request)
{
    $items = CartItem::with([
        'product.images',
        'variant',
    ])
        ->where('user_id', $request->user()->id)
        ->get()
        ->map(function ($cartItem) {
            $product = $cartItem->product;
            $variant = $cartItem->variant;

            $image = $product?->images->firstWhere('is_primary', true)
                ?? $product?->images->first();

            return [
                'id' => $cartItem->id,
                'product_id' => $cartItem->product_id,
                'variant_id' => $cartItem->product_variant_id,
                'nama' => $product?->name ?? 'Produk',
                'harga' => (float) ($variant?->price ?? 0),
                'gambar' => $image
                    ? asset($image->image_path)
                    : '',
                'warna' => $variant?->color ?? '',
                'ukuran' => $variant?->size ?? '',
                'qty' => $cartItem->quantity,
                'stock' => $variant?->stock ?? 0,
            ];
        });

    return view('cart', compact('items'));
}

    private function getUserCart(Request $request)
    {
        return CartItem::with(['product', 'variant'])
            ->where('user_id', $request->user()->id)
            ->get();
    }

    public function add(Request $request)
    {
        $data = $request->validate([
            'variant_id' => 'required|integer|min:1',
            'quantity' => 'nullable|integer|min:1|max:99',
        ]);

        $quantity = (int) ($data['quantity'] ?? 1);

        DB::transaction(function () use ($request, $data, $quantity) {
            $variant = ProductVariant::whereKey($data['variant_id'])
                ->where('is_active', true)
                ->lockForUpdate()
                ->first();

            if (
                !$variant ||
                !$variant->product ||
                !$variant->product->is_active
            ) {
                throw ValidationException::withMessages([
                    'variant_id' => 'Produk atau varian tidak tersedia.',
                ]);
            }

            $cartItem = CartItem::where('user_id', $request->user()->id)
                ->where('product_variant_id', $variant->id)
                ->lockForUpdate()
                ->first();

            $newQuantity = $quantity + ($cartItem?->quantity ?? 0);

            if ($newQuantity > $variant->stock) {
                throw ValidationException::withMessages([
                    'quantity' => 'Jumlah melebihi stok yang tersedia.',
                ]);
            }

            if ($cartItem) {
                $cartItem->update(['quantity' => $newQuantity]);
            } else {
                CartItem::create([
                    'user_id' => $request->user()->id,
                    'product_id' => $variant->product_id,
                    'product_variant_id' => $variant->id,
                    'quantity' => $quantity,
                ]);
            }
        });

        return response()->json([
            'message' => 'Produk berhasil ditambahkan ke keranjang.',
            'count' => CartItem::where('user_id', $request->user()->id)
                ->count(),
        ]);
    }

    public function update(Request $request, CartItem $cartItem)
    {
        $data = $request->validate([
            'quantity' => 'required|integer|min:1|max:99',
        ]);

        abort_unless(
            $cartItem->user_id === $request->user()->id,
            404
        );

        DB::transaction(function () use ($request, $cartItem, $data) {
            $variant = ProductVariant::whereKey(
                $cartItem->product_variant_id
            )->lockForUpdate()->firstOrFail();

            if (!$variant->is_active || !$variant->product?->is_active) {
                throw ValidationException::withMessages([
                    'quantity' => 'Produk sudah tidak tersedia.',
                ]);
            }

            if ($data['quantity'] > $variant->stock) {
                throw ValidationException::withMessages([
                    'quantity' => 'Jumlah melebihi stok yang tersedia.',
                ]);
            }

            $cartItem->update(['quantity' => $data['quantity']]);
        });

        return response()->json(['message' => 'Jumlah berhasil diperbarui.']);
    }

    public function remove(Request $request, CartItem $cartItem)
    {
        abort_unless(
            $cartItem->user_id === $request->user()->id,
            404
        );

        $cartItem->delete();

        return response()->json(['message' => 'Item berhasil dihapus.']);
    }

    public function clear(Request $request)
    {
        CartItem::where('user_id', $request->user()->id)->delete();

        return response()->json(['message' => 'Keranjang berhasil dikosongkan.']);
    }
}
