public function index(Request $request)
{
    $items = CartItem::with(['product.images', 'variant'])
        ->where('user_id', $request->user()->id)
        ->get()
        ->map(function ($cartItem) {
            $product = $cartItem->product;
            $variant = $cartItem->variant;

            $image = $product?->images->firstWhere('is_primary', true)
                ?? $product?->images->first();

            return [
                'id' => $cartItem->id,
                'product_id' => $cartItem->product_id,
                'variant_id' => $cartItem->product_variant_id,
                'nama' => $product?->name ?? 'Produk',
                'harga' => (float) ($variant?->price ?? 0),
                'gambar' => $image ? asset($image->image_path) : '',
                'warna' => $variant?->color ?? '',
                'ukuran' => $variant?->size ?? '',
                'qty' => $cartItem->quantity,
                'stock' => $variant?->stock ?? 0,
            ];
        });

    if ($items->isEmpty()) {
        return redirect()
            ->route('cart.page')
            ->with('error', 'Keranjang belanja masih kosong.');
    }

    return view('checkout', compact('items'));
}
