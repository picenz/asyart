<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\ProfileController;
use App\Http\Controllers\ApparelController;
use App\Http\Controllers\CheckoutController;
use App\Http\Controllers\CartController;
use App\Http\Controllers\Auth\GoogleAuthController;
use App\Http\Controllers\Admin\OrderController as AdminOrderController;
use App\Http\Controllers\Customer\OrderController as CustomerOrderController;

// ========================================
// PUBLIC ROUTES (BISA DIAKSES GUEST)
// ========================================

Route::get('/', [ApparelController::class, 'index'])
    ->name('home');

Route::get('/search', [ApparelController::class, 'search'])
    ->name('search.page');

Route::get('/bag', [ApparelController::class, 'cart'])
    ->name('cart.page');

Route::get('/product/{id}', [ApparelController::class, 'show'])
    ->name('product.detail');


// ========================================
// ROUTES KHUSUS CUSTOMER YANG SUDAH LOGIN
// ========================================

Route::middleware(['auth', 'role:customer'])->group(function () {
    Route::get('/bag', [CartController::class, 'index'])
        ->name('cart.page');
        Route::get('/checkout', [CheckoutController::class, 'index'])
    ->name('checkout');

Route::post('/checkout/process', [CheckoutController::class, 'store'])
    ->name('checkout.process');

    Route::post('/cart/items', [CartController::class, 'add'])
        ->name('cart.add');

    Route::patch('/cart/items/{cartItem}', [CartController::class, 'update'])
        ->name('cart.update');

    Route::delete('/cart/items/{cartItem}', [CartController::class, 'remove'])
        ->name('cart.remove');

    Route::delete('/cart', [CartController::class, 'clear'])
        ->name('cart.clear');
});


// ========================================
// ROUTES KHUSUS ADMIN
// ========================================

Route::middleware(['auth', 'role:admin'])->group(function () {

    Route::get('/admin/dashboard', function () {
        return view('admin.orders');
    })->name('admin.dashboard');

    Route::get('/admin/orders', [AdminOrderController::class, 'index'])
        ->name('admin.orders');
});


// ========================================
// DASHBOARD PENGARAH BERDASARKAN ROLE
// ========================================

Route::middleware('auth')->get('/dashboard', function () {

    if (auth()->user()->role === 'admin') {
        return redirect()->route('admin.dashboard');
    }

    if (auth()->user()->role === 'customer') {
        return redirect()->route('customer.dashboard');
    }


    abort(403);
})->name('dashboard');


// ========================================
// PROFILE (ADMIN DAN CUSTOMER)
// ========================================

Route::middleware('auth')->group(function () {

    Route::get('/profile', [ProfileController::class, 'edit'])
        ->name('profile.edit');

    Route::patch('/profile', [ProfileController::class, 'update'])
        ->name('profile.update');

    Route::delete('/profile', [ProfileController::class, 'destroy'])
        ->name('profile.destroy');

    Route::get('/profile/orders', [CustomerOrderController::class, 'index'])
        ->name('profile.orders');

    Route::get('/profile/addresses', function () {
        return view('addresses');
    })->name('profile.addresses');
});

Route::get('/product/{id}', [ApparelController::class, 'show'])
    ->name('product.detail');

    Route::get('/auth/google', [GoogleAuthController::class, 'redirect'])
    ->middleware('guest')
    ->name('google.redirect');

Route::get('/auth/google/callback', [GoogleAuthController::class, 'callback'])
    ->name('google.callback');



// ========================================
// BREEZE AUTH ROUTES
// ========================================

require __DIR__ . '/auth.php';
